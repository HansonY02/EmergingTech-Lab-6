# Preserved weakness and revision

Initial candidate: v0.1; primary_response_v0_1.json. Course validator passed. Weak phrases: "worthwhile net productivity improvement" and "without worse quality". The trial had a time/budget cap but lacked an operational success rule, named accountable owner and explicit inconclusive-result handling. This is a decision-quality weakness, not a JSON failure.

Smallest correction: append the measurable-decisions section to specialist_instructions.md and update metadata to v0.2. Keep all three cases unchanged. Retest primary and both organizational contrasts. Final response names Support Manager, comparator, total labor/cost measure, proposed 10% productivity gate, a one-percentage-point quality margin with uncertainty, stop events and a no-automatic-scaling rule.

These thresholds are proposed management choices, not validated safe limits. An analyst must calculate feasibility/power from baseline volume and clustered data before a live trial. Six weeks or a zero-event sample cannot guarantee rare-event safety. The remaining limitation is unverified vendor/control evidence and no actual local pilot data.
