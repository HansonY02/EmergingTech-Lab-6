# Emerging Technology Adoption Agent

Student: Zonghan Yang (zy3609). Assignment 6, November 3, 2026.

Run the course tools from scaffold root. No API account is required.

```bash
python tools/check_frozen_core.py
python tools/build_prompt.py --agent agents/adoption_agent --case agents/adoption_agent/cases/primary.json
python tools/validate_response.py agents/adoption_agent/responses/primary_response.json
```

Submit the generated packet to ChatGPT for a new interactive run. Repeat for contrast_1 and contrast_2. Existing responses were produced in one ChatGPT/Codex conversation; see records/run_provenance.md. Review source_register.json before reuse because product and market evidence can change. No vendor is selected and all organizational data are hypothetical.
